//
//  musenseApp.swift
//  musense Watch App
//
//  Created by Yu Zhang on 17/9/2025.
//

import SwiftUI

@main
struct musense_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
